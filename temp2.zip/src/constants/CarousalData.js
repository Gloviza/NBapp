export const pediatricCarousalData = [
  { imgPath: "p1.jpg", alternateName: "abc" },
  { imgPath: "p1.jpg", alternateName: "abc" },
  { imgPath: "p1.jpg", alternateName: "abc" },
];

export const gynCarousalData = [
  { imgPath: "p1.jpg", alternateName: "abc" },
  { imgPath: "p1.jpg", alternateName: "abc" },
  { imgPath: "p1.jpg", alternateName: "abc" },
];

export const phyCarousalData = [
  { imgPath: "p1.jpg", alternateName: "abc" },
  { imgPath: "p1.jpg", alternateName: "abc" },
  { imgPath: "p1.jpg", alternateName: "abc" },
];

export const surCarousalData = [
  { imgPath: "p1.jpg", alternateName: "abc" },
  { imgPath: "p1.jpg", alternateName: "abc" },
  { imgPath: "p1.jpg", alternateName: "abc" },
];
